import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import { CodeTruthMark } from "@/components/codetruth-mark"

export function CtaFooter() {
  return (
    <>
      <section className="scroll-mt-20">
        <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
          <div className="relative overflow-hidden rounded-2xl border border-border bg-card px-6 py-14 text-center sm:px-12 lg:py-20">
            <div
              aria-hidden="true"
              className="pointer-events-none absolute inset-0 opacity-60"
              style={{
                backgroundImage:
                  "radial-gradient(ellipse 50% 60% at 50% 0%, color-mix(in oklch, var(--primary) 18%, transparent), transparent)",
              }}
            />
            <div className="relative mx-auto max-w-2xl">
              <h2 className="text-balance text-3xl font-semibold tracking-tight sm:text-4xl">
                Stay in command of a system growing beyond any single mind.
              </h2>
              <p className="mt-5 text-pretty leading-relaxed text-muted-foreground">
                CodeTruth OS is the cognitive layer every complex software
                project needs but has never had. Request access and connect
                your first project.
              </p>
              <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
                <Button size="lg" className="gap-2 font-medium">
                  Request access
                  <ArrowRight className="size-4" />
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-border bg-transparent font-medium"
                >
                  Talk to the team
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <footer className="border-t border-border">
        <div className="mx-auto flex max-w-7xl flex-col gap-8 px-4 py-12 sm:px-6 lg:flex-row lg:items-center lg:justify-between lg:px-8">
          <div className="flex items-center gap-2.5">
            <CodeTruthMark className="size-6 text-primary" />
            <span className="font-mono text-sm font-semibold tracking-tight">
              CodeTruth<span className="text-primary">OS</span>
            </span>
          </div>

          <nav className="flex flex-wrap gap-x-6 gap-y-3 text-sm text-muted-foreground">
            <a href="#pipeline" className="hover:text-foreground">Pipeline</a>
            <a href="#council" className="hover:text-foreground">Truth Council</a>
            <a href="#confidence" className="hover:text-foreground">Confidence</a>
            <a href="#spatial" className="hover:text-foreground">Spatial</a>
            <a href="#moat" className="hover:text-foreground">Compare</a>
          </nav>

          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()} CodeTruth OS · Sovereign Build
            Philosophy
          </p>
        </div>
      </footer>
    </>
  )
}
