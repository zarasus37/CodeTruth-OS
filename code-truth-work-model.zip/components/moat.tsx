import { Check, Minus, X } from "lucide-react"

type Cell = "yes" | "no" | "partial"

const COLUMNS = [
  "Code Review",
  "Diagrammers",
  "Due Diligence",
  "Eng. Intel.",
]

const ROWS: { capability: string; others: Cell[]; ours: Cell }[] = [
  { capability: "File-level analysis", others: ["yes", "no", "partial", "no"], ours: "yes" },
  { capability: "Architecture reconstruction", others: ["no", "partial", "partial", "no"], ours: "yes" },
  { capability: "Runtime flow inference", others: ["no", "no", "no", "no"], ours: "yes" },
  { capability: "Build-state scoring", others: ["no", "no", "partial", "partial"], ours: "yes" },
  { capability: "Infra gap detection", others: ["no", "no", "partial", "no"], ours: "yes" },
  { capability: "Multi-model adversarial review", others: ["no", "no", "no", "no"], ours: "yes" },
  { capability: "Spatial 3D visualization", others: ["no", "no", "no", "no"], ours: "yes" },
  { capability: "Continuous live model", others: ["no", "no", "no", "partial"], ours: "yes" },
  { capability: "Evidence-linked confidence", others: ["no", "no", "no", "no"], ours: "yes" },
]

function CellMark({ value, emphasis }: { value: Cell; emphasis?: boolean }) {
  if (value === "yes")
    return (
      <Check
        className={`mx-auto size-4 ${emphasis ? "text-primary" : "text-confirmed"}`}
      />
    )
  if (value === "partial")
    return <Minus className="mx-auto size-4 text-inferred" />
  return <X className="mx-auto size-3.5 text-muted-foreground/50" />
}

export function Moat() {
  return (
    <section id="moat" className="scroll-mt-20">
      <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
        <div className="max-w-2xl">
          <p className="font-mono text-xs uppercase tracking-widest text-primary">
            Competitive moat
          </p>
          <h2 className="mt-4 text-balance text-3xl font-semibold tracking-tight sm:text-4xl">
            No current platform covers all five domains coherently.
          </h2>
          <p className="mt-5 text-pretty leading-relaxed text-muted-foreground">
            CodeTruth sits at the intersection of architecture intelligence,
            technical due diligence, AI-assisted reasoning, spatial
            visualization, and institutional governance.
          </p>
        </div>

        <div className="mt-12 overflow-x-auto rounded-xl border border-border">
          <table className="w-full min-w-[640px] border-collapse text-sm">
            <thead>
              <tr className="border-b border-border bg-card/60">
                <th className="px-5 py-4 text-left font-medium text-muted-foreground">
                  Capability
                </th>
                {COLUMNS.map((c) => (
                  <th
                    key={c}
                    className="px-3 py-4 text-center text-xs font-medium text-muted-foreground"
                  >
                    {c}
                  </th>
                ))}
                <th className="bg-primary/10 px-3 py-4 text-center text-xs font-semibold text-primary">
                  CodeTruth OS
                </th>
              </tr>
            </thead>
            <tbody>
              {ROWS.map((row) => (
                <tr
                  key={row.capability}
                  className="border-b border-border/60 last:border-0"
                >
                  <td className="px-5 py-3.5 text-foreground">
                    {row.capability}
                  </td>
                  {row.others.map((cell, i) => (
                    <td key={i} className="px-3 py-3.5">
                      <CellMark value={cell} />
                    </td>
                  ))}
                  <td className="bg-primary/[0.07] px-3 py-3.5">
                    <CellMark value={row.ours} emphasis />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  )
}
