const PRINCIPLES = [
  {
    title: "System Truth over File Truth",
    desc: "A project is not its files. We reason about the system those files produce, not just the syntax.",
  },
  {
    title: "Evidence-Linked Every Claim",
    desc: "No output states anything without a source chain, a confidence label, and what could not be confirmed.",
  },
  {
    title: "Confidence Transparency",
    desc: "Inferred architecture is never presented with the same weight as confirmed architecture.",
  },
  {
    title: "Non-Coder Sovereignty",
    desc: "Translate code-level reality into structural language any intelligent builder can act on.",
  },
  {
    title: "Spatial Comprehension",
    desc: "Render systems as navigable spaces, because human cognition handles space better than lists.",
  },
  {
    title: "Continuous, Not One-Time",
    desc: "Maintain the model as the system evolves. Always have access to the current truth.",
  },
  {
    title: "Understanding to Execution",
    desc: "Every insight connects to a plan: what to build, in what order, validated against what criteria.",
  },
  {
    title: "Institutional-Grade, Single Operator",
    desc: "Institutional rigor through an interface one builder can operate without an infra team.",
  },
]

export function Principles() {
  return (
    <section className="scroll-mt-20">
      <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
        <div className="max-w-2xl">
          <p className="font-mono text-xs uppercase tracking-widest text-primary">
            Core philosophy
          </p>
          <h2 className="mt-4 text-balance text-3xl font-semibold tracking-tight sm:text-4xl">
            Eight principles that separate truth from hallucination.
          </h2>
        </div>

        <div className="mt-12 grid gap-x-10 gap-y-8 sm:grid-cols-2 lg:grid-cols-4">
          {PRINCIPLES.map((p, i) => (
            <div key={p.title} className="border-t border-border pt-5">
              <span className="font-mono text-xs text-primary">
                {String(i + 1).padStart(2, "0")}
              </span>
              <h3 className="mt-3 text-sm font-semibold text-foreground">
                {p.title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {p.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
