import { Button } from "@/components/ui/button"
import { ArrowRight, Check, CircleHelp, TriangleAlert } from "lucide-react"

const EVIDENCE_ROWS = [
  {
    state: "confirmed",
    label: "Auth flow",
    detail: "session.ts → middleware.ts → /api/login",
    color: "text-confirmed",
    Icon: Check,
  },
  {
    state: "inferred",
    label: "Payment service",
    detail: "stripe.webhook.ts · 2 evidence sources",
    color: "text-inferred",
    Icon: TriangleAlert,
  },
  {
    state: "missing",
    label: "CI/CD pipeline",
    detail: "no workflow files detected",
    color: "text-contradicted",
    Icon: TriangleAlert,
  },
  {
    state: "unknown",
    label: "Backup & recovery",
    detail: "insufficient evidence to determine",
    color: "text-unknown",
    Icon: CircleHelp,
  },
]

export function Hero() {
  return (
    <section id="top" className="relative overflow-hidden">
      {/* technical grid backdrop */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-[0.5]"
        style={{
          backgroundImage:
            "linear-gradient(to right, color-mix(in oklch, var(--border) 60%, transparent) 1px, transparent 1px), linear-gradient(to bottom, color-mix(in oklch, var(--border) 60%, transparent) 1px, transparent 1px)",
          backgroundSize: "56px 56px",
          maskImage:
            "radial-gradient(ellipse 80% 60% at 50% 0%, black 30%, transparent 80%)",
        }}
      />

      <div className="relative mx-auto grid max-w-7xl gap-12 px-4 pb-20 pt-16 sm:px-6 lg:grid-cols-[1.05fr_0.95fr] lg:items-center lg:gap-10 lg:px-8 lg:pb-28 lg:pt-24">
        <div>
          <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-3 py-1 font-mono text-xs text-muted-foreground">
            <span className="size-1.5 rounded-full bg-primary" />
            Project Cognition Platform
          </div>

          <h1 className="mt-6 text-balance text-4xl font-semibold leading-[1.05] tracking-tight sm:text-5xl lg:text-6xl">
            Know the truth of your system,{" "}
            <span className="text-primary">not just its files.</span>
          </h1>

          <p className="mt-6 max-w-xl text-pretty text-base leading-relaxed text-muted-foreground sm:text-lg">
            CodeTruth OS maintains a live, evidence-linked, spatially-navigable
            model of your software project — what it is, how it runs, where it
            breaks, and exactly what to build next. A cognitive instrument for
            systems that have outgrown any single mind.
          </p>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Button size="lg" className="gap-2 font-medium">
              Request access
              <ArrowRight className="size-4" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="gap-2 border-border bg-transparent font-medium"
            >
              Read the thesis
            </Button>
          </div>

          <dl className="mt-10 grid max-w-md grid-cols-3 gap-6 border-t border-border pt-6">
            {[
              { v: "8", l: "Analysis layers" },
              { v: "5", l: "Adversarial models" },
              { v: "10k+", l: "Files per project" },
            ].map((s) => (
              <div key={s.l}>
                <dt className="font-mono text-2xl font-semibold text-foreground">
                  {s.v}
                </dt>
                <dd className="mt-1 text-xs leading-relaxed text-muted-foreground">
                  {s.l}
                </dd>
              </div>
            ))}
          </dl>
        </div>

        {/* evidence panel visual */}
        <div className="relative">
          <div className="rounded-xl border border-border bg-card/80 shadow-2xl shadow-black/40 backdrop-blur">
            <div className="flex items-center justify-between border-b border-border px-4 py-3">
              <div className="flex items-center gap-2 font-mono text-xs text-muted-foreground">
                <span className="size-2.5 rounded-full bg-contradicted/70" />
                <span className="size-2.5 rounded-full bg-inferred/70" />
                <span className="size-2.5 rounded-full bg-confirmed/70" />
                <span className="ml-2">consensus_truth_report.json</span>
              </div>
              <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                live model
              </span>
            </div>

            <div className="divide-y divide-border/70">
              {EVIDENCE_ROWS.map((row) => (
                <div
                  key={row.label}
                  className="flex items-center gap-3 px-4 py-3.5"
                >
                  <row.Icon className={`size-4 shrink-0 ${row.color}`} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-foreground">
                        {row.label}
                      </span>
                      <span
                        className={`font-mono text-[10px] uppercase tracking-wider ${row.color}`}
                      >
                        {row.state}
                      </span>
                    </div>
                    <p className="truncate font-mono text-xs text-muted-foreground">
                      {row.detail}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            <div className="border-t border-border px-4 py-3 font-mono text-xs text-muted-foreground">
              <span className="text-confirmed">{"// "}</span>
              every claim carries a source chain &amp; confidence label
            </div>
          </div>

          <div
            aria-hidden="true"
            className="absolute -right-6 -top-6 -z-10 size-40 rounded-full bg-primary/10 blur-3xl"
          />
        </div>
      </div>
    </section>
  )
}
