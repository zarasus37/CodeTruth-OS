import { cn } from "@/lib/utils"

/**
 * CodeTruth OS brand mark — a layered node connected by an evidence path,
 * representing a system model assembled from linked evidence.
 */
export function CodeTruthMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      className={cn(className)}
    >
      <path d="M12 2 3 6.5v11L12 22l9-4.5v-11L12 2Z" opacity="0.45" />
      <path d="M12 7 7.5 9.25v5.5L12 17l4.5-2.25v-5.5L12 7Z" />
      <circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none" />
    </svg>
  )
}
