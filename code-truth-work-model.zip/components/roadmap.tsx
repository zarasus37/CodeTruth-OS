const PHASES = [
  {
    version: "V1",
    title: "Truth Engine",
    status: "Available",
    statusClass: "text-confirmed border-confirmed/40 bg-confirmed/10",
    desc: "Evidence-backed analysis: architecture reconstruction, build-state scoring, infra gap detection, remediation planning, and the truth council. JS, TypeScript, and Python.",
  },
  {
    version: "V2",
    title: "Spatial Navigator",
    status: "In progress",
    statusClass: "text-inferred border-inferred/40 bg-inferred/10",
    desc: "Interactive spatial visualization, snapshot diff, and animated evolution view. Expanded support for Python AI agents, Solidity contracts, and multi-service deployments.",
  },
  {
    version: "V3",
    title: "Cognition OS",
    status: "Planned",
    statusClass: "text-unknown border-unknown/40 bg-unknown/10",
    desc: "Full continuous project model with live re-analysis on push, 3D navigation, team governance, AI agent and DeFi protocol understanding, and portfolio-level maturity scoring.",
  },
]

export function Roadmap() {
  return (
    <section className="border-t border-border bg-card/30">
      <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
        <div className="max-w-2xl">
          <p className="font-mono text-xs uppercase tracking-widest text-primary">
            Versioned roadmap
          </p>
          <h2 className="mt-4 text-balance text-3xl font-semibold tracking-tight sm:text-4xl">
            From truth engine to project cognition OS.
          </h2>
        </div>

        <div className="mt-12 grid gap-px overflow-hidden rounded-xl border border-border bg-border md:grid-cols-3">
          {PHASES.map((phase) => (
            <div key={phase.version} className="flex flex-col gap-4 bg-card p-6">
              <div className="flex items-center justify-between">
                <span className="font-mono text-sm font-semibold text-primary">
                  {phase.version}
                </span>
                <span
                  className={`rounded-full border px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider ${phase.statusClass}`}
                >
                  {phase.status}
                </span>
              </div>
              <h3 className="text-lg font-semibold text-foreground">
                {phase.title}
              </h3>
              <p className="text-sm leading-relaxed text-muted-foreground">
                {phase.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
