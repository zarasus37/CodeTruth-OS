const FAILURES = [
  "Misdirected effort on the wrong surfaces",
  "Integration failures discovered far too late",
  "Architectural drift between intent and code",
  "Onboarding failure for new contributors",
  "Owners losing the ability to reason about their own system",
  "Compounding technical debt that stays invisible",
]

export function Problem() {
  return (
    <section className="border-y border-border bg-card/30">
      <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
        <div className="grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-primary">
              The core problem
            </p>
            <h2 className="mt-4 text-balance text-3xl font-semibold tracking-tight sm:text-4xl">
              Cognitive compression failure
            </h2>
            <p className="mt-5 text-pretty leading-relaxed text-muted-foreground">
              As a project grows in files, agents, integrations, and
              environments, the human ability to hold the whole system in mind
              deteriorates faster than the project&apos;s actual complexity
              grows. The mental model and the codebase silently diverge.
            </p>
            <p className="mt-4 text-pretty leading-relaxed text-muted-foreground">
              This is not caused by poor coding skill or thin documentation.
              It is caused by the absence of a maintained, navigable
              representation of the whole project.
            </p>
          </div>

          <ul className="grid gap-px overflow-hidden rounded-xl border border-border bg-border sm:grid-cols-2">
            {FAILURES.map((f, i) => (
              <li
                key={f}
                className="flex items-start gap-3 bg-card p-5"
              >
                <span className="mt-0.5 font-mono text-xs text-muted-foreground">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <span className="text-sm leading-relaxed text-foreground">
                  {f}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  )
}
