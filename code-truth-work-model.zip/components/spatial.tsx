import Image from "next/image"

const FEATURES = [
  "Services & agents as navigable spatial objects",
  "Data flows and runtime paths as spatial connections",
  "Missing infrastructure as visible gaps and empty sockets",
  "Confidence encoded as visual solidity and opacity",
  "Risk concentration rendered as heat zones",
  "Click any node to inspect its evidence chain",
]

export function Spatial() {
  return (
    <section id="spatial" className="scroll-mt-20 border-y border-border bg-card/30">
      <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
        <div className="grid gap-12 lg:grid-cols-[1.05fr_0.95fr] lg:items-center lg:gap-16">
          <div className="order-2 lg:order-1">
            <p className="font-mono text-xs uppercase tracking-widest text-primary">
              Layer 7 · Spatial navigator
            </p>
            <h2 className="mt-4 text-balance text-3xl font-semibold tracking-tight sm:text-4xl">
              Perceive your system the way you perceive a space.
            </h2>
            <p className="mt-5 text-pretty leading-relaxed text-muted-foreground">
              Human spatial reasoning vastly outperforms list-reading for
              complex environments. CodeTruth turns a 200-file, 15-service,
              multi-agent project into a navigable space — making
              institutional-level complexity accessible to builders who are not
              traditional engineers.
            </p>

            <ul className="mt-8 grid gap-3 sm:grid-cols-2">
              {FEATURES.map((f) => (
                <li key={f} className="flex items-start gap-3">
                  <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-primary" />
                  <span className="text-sm leading-relaxed text-foreground">
                    {f}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          <div className="order-1 lg:order-2">
            <div className="overflow-hidden rounded-xl border border-border bg-background shadow-2xl shadow-black/40">
              <Image
                src="/spatial-system-map.png"
                alt="A 3D spatial rendering of a software system: services as glowing nodes connected by data-flow paths, with missing infrastructure shown as incomplete wireframe surfaces and risk zones glowing amber and red."
                width={1024}
                height={1024}
                className="h-full w-full object-cover"
                priority
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
