import { Network, ShieldAlert, Server, Building2, Route } from "lucide-react"

const MODELS = [
  {
    name: "Architecture Model",
    Icon: Network,
    desc: "System decomposition, boundaries, coupling, and structural debt.",
  },
  {
    name: "Runtime Model",
    Icon: Route,
    desc: "Execution paths, user flow, and integration breakpoints.",
  },
  {
    name: "DevOps Model",
    Icon: Server,
    desc: "Deployability, environment completeness, secrets, and release process.",
  },
  {
    name: "Security Model",
    Icon: ShieldAlert,
    desc: "Trust boundaries, credential exposure, and exploit patterns.",
  },
  {
    name: "Planning Model",
    Icon: Building2,
    desc: "Converts all findings into a sequenced, taskable implementation plan.",
  },
]

const MECHANICS = [
  "Independent first-pass assessment on shared evidence",
  "Cross-review pass where models challenge each other",
  "Explicit contradiction detection and surfacing",
  "Consensus that preserves disagreement instead of averaging it",
]

export function TruthCouncil() {
  return (
    <section id="council" className="scroll-mt-20 border-y border-border bg-card/30">
      <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
        <div className="grid gap-12 lg:grid-cols-[1fr_1fr] lg:gap-16">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-primary">
              Layer 5 · AI governance
            </p>
            <h2 className="mt-4 text-balance text-3xl font-semibold tracking-tight sm:text-4xl">
              The Multi-Model Truth Council
            </h2>
            <p className="mt-5 text-pretty leading-relaxed text-muted-foreground">
              Five role-specialized models review your system adversarially.
              Where a single model hallucinates with confidence, the Council
              surfaces disagreement — preserving contradiction rather than
              hiding it behind an average.
            </p>

            <ul className="mt-8 space-y-3">
              {MECHANICS.map((m) => (
                <li key={m} className="flex items-start gap-3">
                  <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-primary" />
                  <span className="text-sm leading-relaxed text-foreground">
                    {m}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          <div className="grid gap-px self-start overflow-hidden rounded-xl border border-border bg-border">
            {MODELS.map((model) => (
              <div
                key={model.name}
                className="flex items-start gap-4 bg-card p-5"
              >
                <span className="inline-flex size-9 shrink-0 items-center justify-center rounded-lg border border-border bg-background text-primary">
                  <model.Icon className="size-4" />
                </span>
                <div>
                  <h3 className="text-sm font-semibold text-foreground">
                    {model.name}
                  </h3>
                  <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                    {model.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
