const LEVELS = [
  {
    label: "Confirmed",
    desc: "Directly evidenced in source.",
    dot: "bg-confirmed",
    text: "text-confirmed",
    bar: "100%",
  },
  {
    label: "Strongly Inferred",
    desc: "Multiple evidence sources agree.",
    dot: "bg-confirmed/70",
    text: "text-confirmed/80",
    bar: "80%",
  },
  {
    label: "Weakly Inferred",
    desc: "Plausible, but sparse evidence.",
    dot: "bg-inferred",
    text: "text-inferred",
    bar: "55%",
  },
  {
    label: "Unknown",
    desc: "Cannot be determined from evidence.",
    dot: "bg-unknown",
    text: "text-unknown",
    bar: "30%",
  },
  {
    label: "Contradicted",
    desc: "Evidence sources conflict.",
    dot: "bg-contradicted",
    text: "text-contradicted",
    bar: "45%",
  },
]

export function Confidence() {
  return (
    <section id="confidence" className="scroll-mt-20">
      <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
        <div className="max-w-2xl">
          <p className="font-mono text-xs uppercase tracking-widest text-primary">
            Quality, trust & confidence
          </p>
          <h2 className="mt-4 text-balance text-3xl font-semibold tracking-tight sm:text-4xl">
            Never present a guess with the weight of a fact.
          </h2>
          <p className="mt-5 text-pretty leading-relaxed text-muted-foreground">
            Every piece of understanding is tagged. Builders get a usable map
            of what is known, inferred, and unproven — not a false sense of
            certainty. No output states anything without pointing to the
            evidence that justifies it.
          </p>
        </div>

        <div className="mt-12 grid gap-px overflow-hidden rounded-xl border border-border bg-border md:grid-cols-5">
          {LEVELS.map((lvl) => (
            <div key={lvl.label} className="flex flex-col gap-4 bg-card p-5">
              <div className="flex items-center gap-2">
                <span className={`size-2.5 rounded-full ${lvl.dot}`} />
                <span
                  className={`font-mono text-xs uppercase tracking-wider ${lvl.text}`}
                >
                  {lvl.label}
                </span>
              </div>
              <div className="h-1.5 w-full overflow-hidden rounded-full bg-secondary">
                <div
                  className={`h-full rounded-full ${lvl.dot}`}
                  style={{ width: lvl.bar }}
                />
              </div>
              <p className="text-sm leading-relaxed text-muted-foreground">
                {lvl.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
