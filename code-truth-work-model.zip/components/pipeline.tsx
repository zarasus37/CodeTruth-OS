import {
  Download,
  ScanText,
  Boxes,
  Gauge,
  Scale,
  ListChecks,
  Box,
  Users,
} from "lucide-react"

const LAYERS = [
  {
    n: 1,
    name: "Ingestion",
    Icon: Download,
    desc: "Connect repos, branches, and uploads. Immutable, hash-chained snapshots with framework auto-detection.",
  },
  {
    n: 2,
    name: "Parsing & Intelligence",
    Icon: ScanText,
    desc: "AST extraction, symbol & dependency graphs, route maps, schema and secret detection.",
  },
  {
    n: 3,
    name: "Reconstruction",
    Icon: Boxes,
    desc: "Assemble file-level evidence into a systems model: service boundaries, data flows, deployment topology.",
  },
  {
    n: 4,
    name: "Evaluation",
    Icon: Gauge,
    desc: "Score across 10 domains, detect 12 gap categories, and classify findings by severity.",
  },
  {
    n: 5,
    name: "Multi-Model Truth Council",
    Icon: Scale,
    desc: "Five role-specialized models assess independently, cross-review, and synthesize a contradiction-aware report.",
  },
  {
    n: 6,
    name: "Planning",
    Icon: ListChecks,
    desc: "Convert findings into a sequenced, dependency-aware, ticket-ready implementation roadmap.",
  },
  {
    n: 7,
    name: "Spatial Visualization",
    Icon: Box,
    desc: "Render the project model as a navigable space — services as zones, gaps as visible incomplete surfaces.",
  },
  {
    n: 8,
    name: "Governance & Collaboration",
    Icon: Users,
    desc: "Role-based workspaces, human review, approval workflows, audit logs, and reproducible report signing.",
  },
]

export function Pipeline() {
  return (
    <section id="pipeline" className="scroll-mt-20">
      <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
        <div className="max-w-2xl">
          <p className="font-mono text-xs uppercase tracking-widest text-primary">
            The functional work model
          </p>
          <h2 className="mt-4 text-balance text-3xl font-semibold tracking-tight sm:text-4xl">
            One pipeline. Eight layers. Raw files to executable plan.
          </h2>
          <p className="mt-5 text-pretty leading-relaxed text-muted-foreground">
            Every project flows through the same evidence pipeline — from
            ingestion through governance — producing a continuously maintained
            system model rather than a one-time report.
          </p>
        </div>

        <ol className="mt-12 grid gap-px overflow-hidden rounded-xl border border-border bg-border sm:grid-cols-2 lg:grid-cols-4">
          {LAYERS.map((layer) => (
            <li
              key={layer.n}
              className="group relative flex flex-col gap-4 bg-card p-6 transition-colors hover:bg-secondary/60"
            >
              <div className="flex items-center justify-between">
                <span className="inline-flex size-10 items-center justify-center rounded-lg border border-border bg-background text-primary">
                  <layer.Icon className="size-5" />
                </span>
                <span className="font-mono text-xs text-muted-foreground">
                  L{layer.n}
                </span>
              </div>
              <div>
                <h3 className="text-sm font-semibold text-foreground">
                  {layer.name}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {layer.desc}
                </p>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  )
}
