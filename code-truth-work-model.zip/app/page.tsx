import { SiteHeader } from "@/components/site-header"
import { Hero } from "@/components/hero"
import { Problem } from "@/components/problem"
import { Principles } from "@/components/principles"
import { Pipeline } from "@/components/pipeline"
import { TruthCouncil } from "@/components/truth-council"
import { Confidence } from "@/components/confidence"
import { Spatial } from "@/components/spatial"
import { Moat } from "@/components/moat"
import { Roadmap } from "@/components/roadmap"
import { CtaFooter } from "@/components/cta-footer"

export default function Page() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />
      <main>
        <Hero />
        <Problem />
        <Principles />
        <Pipeline />
        <TruthCouncil />
        <Confidence />
        <Spatial />
        <Moat />
        <Roadmap />
        <CtaFooter />
      </main>
    </div>
  )
}
